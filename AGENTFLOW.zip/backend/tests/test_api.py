from io import BytesIO
import pymupdf as fitz
from docx import Document as WordDocument


def text_file(content=b"Supplier: Acme Limited\nDue Date: November 8, 2026\nContact: ops@example.com\nInvoice total: 1200"):
    return ("sample.txt",content,"text/plain")

def test_health_and_schema(client):
    r=client.get("/api/health");assert r.status_code==200 and r.json()["processing"]=="deterministic-rules" and r.json()["gemini_configured"] is False
    assert client.get("/openapi.json").status_code==200

def test_text_upload_extraction_and_analysis(client):
    r=client.post("/api/documents/upload",files={"file":text_file()})
    assert r.status_code==201,r.text
    data=r.json();assert data["filename"]=="sample.txt";assert data["status"]=="Processed";assert data["category"]=="Invoice"
    assert data["fields"]["Email"]=="ops@example.com"
    assert "Due Date" in data["fields"]
    analysis=client.post(f"/api/documents/{data['id']}/analyze")
    assert analysis.status_code==200 and analysis.json()["category"]=="Invoice"
    assert analysis.json()["detected_deadlines"]

def test_pdf_extraction(client):
    pdf=fitz.open();page=pdf.new_page();page.insert_text((72,72),"INVOICE\nSupplier: Sample Corp\nDue Date: 11/10/2026")
    payload=pdf.tobytes();pdf.close()
    r=client.post("/api/documents/upload",files={"file":("invoice.pdf",payload,"application/pdf")})
    assert r.status_code==201,r.text
    assert "Sample Corp" in r.json()["fields"]["Supplier"]

def test_docx_extraction(client):
    doc=WordDocument();doc.add_paragraph("PURCHASE ORDER");doc.add_paragraph("Vendor: Acme Supplies");doc.add_paragraph("Expiry Date: 2027-04-30")
    bio=BytesIO();doc.save(bio)
    r=client.post("/api/documents/upload",files={"file":("order.docx",bio.getvalue(),"application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    assert r.status_code==201,r.text
    assert r.json()["category"]=="Purchase Order"
    assert r.json()["fields"]["Vendor"]=="Acme Supplies"

def test_list_search_and_filters(client):
    client.post("/api/documents/upload",files={"file":text_file()})
    assert client.get("/api/documents?q=example.com").json()["total"]==1
    assert client.get("/api/search",params={"q":"Acme"}).json()["total"]==1
    assert client.get("/api/documents",params={"category":"Invoice"}).json()["total"]==1
    assert client.get("/api/search/status").json()["available"]

def test_download_delete_and_not_found(client):
    data=client.post("/api/documents/upload",files={"file":text_file()}).json()
    r=client.get(f"/api/documents/{data['id']}/download");assert r.status_code==200 and b"Supplier" in r.content
    assert client.delete(f"/api/documents/{data['id']}").status_code==204
    assert client.get(f"/api/documents/{data['id']}").status_code==404

def test_invalid_extension_and_invalid_pdf(client):
    assert client.post("/api/documents/upload",files={"file":("bad.exe",b"x","application/octet-stream")}).status_code==415
    assert client.post("/api/documents/upload",files={"file":("bad.pdf",b"not pdf","application/pdf")}).status_code==422

def test_deadline_crud_dashboard_and_category(client):
    doc=client.post("/api/documents/upload",files={"file":text_file()}).json()
    r=client.post("/api/deadlines",json={"title":"Review renewal","description":"Reminder","due_date":"2027-01-15T00:00:00Z","priority":"High","document_id":doc["id"]})
    assert r.status_code==201,r.text
    deadline=r.json();assert deadline["document_name"]=="sample.txt"
    assert client.patch(f"/api/deadlines/{deadline['id']}",json={"priority":"Low"}).json()["priority"]=="Low"
    assert client.post(f"/api/deadlines/{deadline['id']}/complete").json()["status"]=="Completed"
    notices=client.get("/api/notifications").json();assert any(n["kind"]=="completed" for n in notices["items"])
    dash=client.get("/api/dashboard").json();assert dash["total_documents"]==1 and dash["completed_deadlines"]==1
    assert client.get("/api/categories").status_code==200
    assert client.delete(f"/api/deadlines/{deadline['id']}").status_code==204

def test_fields_assistant_and_text(client):
    data=client.post("/api/documents/upload",files={"file":text_file()}).json()
    assert client.get(f"/api/documents/{data['id']}/text").json()["available"]
    updated=client.patch(f"/api/documents/{data['id']}/fields",json={"fields":{"Manual note":"Verified"}})
    assert updated.status_code==200 and updated.json()["fields"]["Manual note"]=="Verified"
    answer=client.post("/api/assistant/ask",json={"question":"Which invoices are present?"}).json()
    assert answer["mode"]=="rule-based" and "sample.txt" in answer["answer"]

def test_auto_deadline_and_assistant_status(client):
    r=client.post("/api/documents/upload",files={"file":text_file(b"INVOICE\nDue Date: November 8, 2026\nSupplier: Northwind Parts")})
    assert r.status_code==201
    rows=client.get("/api/deadlines").json()
    assert any(x["source"]=="automatic" and "Due Date" in x["title"] for x in rows)
    status=client.get("/api/assistant/status")
    assert status.status_code==200 and status.json()["available"] is True

def test_upload_size_limit(client,monkeypatch):
    import app.routes.documents as route
    monkeypatch.setattr(route,"MAX_FILE_SIZE",5)
    response=client.post("/api/documents/upload",files={"file":("large.txt",b"0123456789","text/plain")})
    assert response.status_code==413

def test_markdown_and_field_edit(client):
    response=client.post("/api/documents/upload",files={"file":("notes.md",b"Company Name: Northwind LLC\nContact: sam@example.org","text/markdown")})
    assert response.status_code==201
    assert response.json()["fields"]["Company Name"]=="Northwind LLC"
    assert client.patch(f"/api/documents/{response.json()['id']}/fields",json={"fields":{"Verified":"yes"}}).status_code==200

def test_gmail_oauth_scaffold_and_in_app_notifications(client,monkeypatch):
    from cryptography.fernet import Fernet
    import app.services.gmail as gmail_service
    missing=client.get("/api/gmail/status").json()
    assert missing["configured"] is False and client.get("/api/gmail/connect").status_code==503
    monkeypatch.setattr(gmail_service,"GOOGLE_CLIENT_ID","test-client-id")
    monkeypatch.setattr(gmail_service,"GOOGLE_CLIENT_SECRET","test-client-secret")
    monkeypatch.setattr(gmail_service,"GOOGLE_REDIRECT_URI","http://localhost:8000/api/gmail/callback")
    monkeypatch.setattr(gmail_service,"GMAIL_TOKEN_ENCRYPTION_KEY",Fernet.generate_key().decode())
    authorization=client.get("/api/gmail/connect",follow_redirects=False)
    assert authorization.status_code==302
    assert "accounts.google.com" in authorization.headers["location"]
    assert "gmail.send" in authorization.headers["location"]
    assert client.get("/api/gmail/status").json()["connected"] is False
    status=client.get("/api/gmail/status")
    assert client.post("/api/gmail/test").status_code==409
    assert status.status_code==200 and status.json()["configured"] is True and status.json()["connected"] is False
    assert client.get("/api/notifications").json()["unread_count"]==0
    assert client.post("/api/notifications/read-all").json()["ok"] is True

def test_gemini_assistant_uses_context_when_configured(client,monkeypatch):
    from google import genai
    import app.routes.assistant as assistant_route
    client.post("/api/documents/upload",files={"file":text_file()})
    class FakeModels:
        def generate_content(self,**kwargs):
            assert "sample.txt" in kwargs["contents"]
            return type("Response",(),{"text":"The stored document lists its due date as November 8, 2026. Verify it against the original."})()
    class FakeClient:
        def __init__(self,**kwargs):assert kwargs["api_key"]=="test-only-key"
        models=FakeModels()
    monkeypatch.setattr(assistant_route,"GEMINI_API_KEY","test-only-key")
    monkeypatch.setattr(genai,"Client",FakeClient)
    response=client.post("/api/assistant/ask",json={"question":"When is this invoice due?"})
    assert response.status_code==200 and response.json()["mode"]=="gemini"
    assert response.json()["sources"][0]["filename"]=="sample.txt"

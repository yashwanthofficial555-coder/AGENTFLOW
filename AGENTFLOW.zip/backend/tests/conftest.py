import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database import Base, get_db
from app.main import create_app
import app.routes.documents as document_routes
import app.routes.assistant as assistant_routes
import app.main as main_module

@pytest.fixture
def client(tmp_path,monkeypatch):
    db_file=tmp_path/"test.db"
    engine=create_engine(f"sqlite:///{db_file}",connect_args={"check_same_thread":False})
    TestingSession=sessionmaker(bind=engine,autoflush=False,expire_on_commit=False)
    Base.metadata.create_all(engine)
    app=create_app(initialize_database=False)
    def override_db():
        session=TestingSession()
        try:yield session
        finally:session.close()
    app.dependency_overrides[get_db]=override_db
    monkeypatch.setattr(document_routes,"STORAGE_DIR",tmp_path/"storage")
    # Tests stay offline even when a developer has a Gemini key in backend/.env.
    monkeypatch.setattr(assistant_routes,"GEMINI_API_KEY","")
    monkeypatch.setattr(main_module,"GEMINI_API_KEY","")
    document_routes.STORAGE_DIR.mkdir(parents=True)
    with TestClient(app) as test_client:yield test_client
    engine.dispose()

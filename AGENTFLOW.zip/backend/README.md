# DocuMind local backend

A local, single-workspace FastAPI document manager. Document extraction, categorization, summaries, search, and deadline detection use conventional Python code, regular expressions, SQLite queries, and extractive text processing. The assistant defaults to deterministic local rules. If `GEMINI_API_KEY` is configured, only the assistant can optionally call Gemini with the user's question and a short set of relevant document excerpts; document processing never uses AI/ML.

## Requirements

- Python 3.11 or newer (tested here with Python 3.13)
- Node is only needed for the companion frontend

## Windows CMD setup

From the repository root:

```cmd
cd backend
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

Optional: edit `.env` to set a database/storage location, file-size cap, permitted browser origins, or Google OAuth credentials. Paths default under `backend/`; Gmail credentials are not required for local in-app notifications. Initialize/upgrade schema, then launch:

```cmd
alembic upgrade head
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Open Swagger at <http://127.0.0.1:8000/docs>, ReDoc at `/redoc`, and health at `/api/health`. The app runs `alembic upgrade head` on startup before seeding document categories; Alembic revisions manage forward schema changes. When developing against the Vite frontend, its `/api` proxy forwards requests to `127.0.0.1:8000`.

## Run both services from VS Code

1. Open the repository root in VS Code and select your backend Python environment (Python 3.11+).
2. Install dependencies with `python -m pip install -r backend/requirements.txt` and run `npm ci` at the repository root.
3. Copy `backend/.env.example` to `backend/.env`. Set `GEMINI_API_KEY` locally if you want chat answers from Gemini; `GEMINI_MODEL` defaults to the exact model `gemini-3.1-flash-lite`. Keep the key in this ignored local file—never in `launch.json`, source code, or a committed file.
4. Press F5 and choose **DocuMind Full Stack**. The launch configuration loads `backend/.env` for FastAPI and starts Vite; Vite proxies `/api` to `127.0.0.1:8000`.
5. Open <http://127.0.0.1:5173>. API health is at <http://127.0.0.1:8000/api/health>; assistant configuration is visible at `/api/assistant/status`.

If the assistant reports rule-based mode, confirm the local `.env` has a non-empty `GEMINI_API_KEY` and `GEMINI_MODEL=gemini-3.1-flash-lite`, then stop and relaunch the FastAPI debug configuration. Google provider capacity may still cause an individual request to fall back to local rules; the backend displays that fallback rather than pretending Gemini answered.

## Other platforms

```bash
cd backend
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
alembic upgrade head
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

## API overview

- `GET /api/health` — status, deterministic document-processing mode, Gemini configuration indicator (key is never returned)
- `POST /api/documents/upload` — multipart field `file`, supported `.pdf`, `.docx`, `.txt`, `.md`, default maximum 15 MiB
- `GET /api/documents` — `q`, `category`, `status`, `date_from`, `date_to`, `sort_by`, `order`, `page`, `page_size`
- `GET /api/documents/{id}` — metadata and extracted fields
- `GET /api/documents/{id}/text` — extracted plain text
- `GET /api/documents/{id}/download` — original file attachment
- `POST /api/documents/{id}/analyze` — re-run deterministic extraction rules
- `PATCH /api/documents/{id}/fields` — JSON `{ "fields": { "Supplier": "Verified name" } }`
- `DELETE /api/documents/{id}` — remove database record and stored file
- `GET /api/search?q=...` and `GET /api/search/status`
- `GET/POST /api/deadlines`, `PATCH/DELETE /api/deadlines/{id}`, `POST /api/deadlines/{id}/complete`
- `GET /api/dashboard` — counts, bytes, categories, recent items, deadline and upload activity
- `GET /api/categories`
- `POST /api/assistant/ask` — Gemini-grounded response when a key is configured, otherwise deterministic rule-based database/text matching
- `GET /api/assistant/status` — indicates whether Gemini is configured without exposing the key
- `GET /api/assistant/history` — currently returns an empty history because conversation persistence is not implemented
- `GET /api/gmail/status`, `GET /api/gmail/connect`, `GET /api/gmail/callback`, `POST /api/gmail/disconnect`, `POST /api/gmail/test` — Google OAuth connection and send-only Gmail delivery
- `GET /api/notifications`, `POST /api/notifications/read-all` — persisted in-app reminder/completion notifications

The workspace remains single-user and has no app-account authentication, authorization, account/workspace switching, or multi-tenant isolation. Optional Gmail connection uses Google OAuth (send-only permission) and encrypts tokens at rest; it does not read Gmail. A Monday/Thursday 9:00 AM Asia/Kolkata in-process job creates in-app reminders and emails overdue/upcoming-within-14-days/review items when Gmail is connected. Completion events are stored in-app and emailed separately; completed items are excluded from the weekly digest. The scheduler requires the backend to be running and assumes one Uvicorn worker. Scanned-image OCR is not included. Gemini credentials, if configured, remain server-side and are never returned by the API. **Do not expose this service to an untrusted network or use it as a public production service without adding app authentication, authorization, and deployment hardening.** CORS is restricted to localhost Vite origins by default. See `GMAIL_SETUP.md` for OAuth setup.

## Processing details and limitations

- PDF extraction uses selectable PDF text with PyMuPDF. DOCX extracts paragraphs and table cells; TXT/Markdown are UTF-8 decoded.
- Scanned image PDFs do not receive OCR; the API returns no extracted text and flags the document for review.
- Category selection uses keyword hit counts and fixed rule lists. Field extraction only returns values matched in labelled lines (dates, business-party labels, emails, phones); it does not infer missing values.
- Summaries choose sentences from source text based on keyword frequency. They are excerpts/paraphrases only in the sense of selected original sentences; no new claims are written.
- Deadlines are created only from explicit due/expiry/renewal labels followed by a parseable date. Users should validate detected dates and extraction results.
- Gemini is optional and used only for assistant question answering. Configure `GEMINI_API_KEY` in the ignored local `backend/.env`; do not commit it. Gemini may receive the question plus relevant extracted text/fields from local files. Do not enable this for confidential documents unless your organization approves that transfer. Rotate a key immediately if it has been pasted into chat, logs, or a repository. Without a configured key, assistant answers stay local and rule-based.
- Compliance values are limited to a rule observation: an explicit expiry date within 30 days is `Upcoming`; a past explicit expiry is `Attention required`; absence of an expiry finding is `—`, not a declaration of legal compliance.

## Run tests

```cmd
cd backend
.venv\Scripts\activate
set PYTHONPATH=.
pytest -q
```

Tests use a temporary SQLite database and temporary document storage. They cover health/schema, TXT/PDF/DOCX extraction, categorization, analysis and automatic deadline detection, search, CRUD, download, validation, dashboard, fields, local assistant, Gmail-unconfigured behavior, and in-app notifications.

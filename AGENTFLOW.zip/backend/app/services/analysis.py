import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import pymupdf
from docx import Document as WordDocument

CATEGORY_RULES: dict[str, tuple[str, ...]] = {
    "Invoice": ("invoice", "tax invoice", "bill to", "invoice number", "invoice no"),
    "Contract": ("agreement", "contract", "terms and conditions", "party of the first part", "lease"),
    "Licence": ("license", "licence", "permit", "registration certificate"),
    "Certificate": ("certificate", "certification", "fire safety", "occupancy certificate"),
    "Purchase Order": ("purchase order", "po number", "order quantity", "purchase requisition"),
    "Tax Document": ("gst return", "tax return", "gstin", "gstr-", "income tax"),
}
KEYWORDS = ("due", "expiry", "expires", "renewal", "payment", "invoice", "contract", "agreement", "licence", "license", "certificate", "gstin", "tax", "obligation", "notice", "effective date", "total", "supplier")
DATE_FORMATS = ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d.%m.%Y", "%d %B %Y", "%d %b %Y", "%B %d, %Y", "%b %d, %Y", "%d-%b-%Y", "%d/%m/%y")
DATE_RE = re.compile(r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2}|\d{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]{3,9},?\s+\d{4}|[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4})\b", re.I)
LABEL_DATE_RE = re.compile(r"(?im)^\s*(due\s+date|payment\s+due(?:\s+date)?|expiry\s+date|expiration\s+date|expires\s+on|valid\s+until|renewal\s+date|renew\s+by|notice\s+date|deadline)\s*[:\-]?\s*(.{0,70})$")

def extract_text(path: Path, extension: str) -> str:
    ext = extension.lower()
    if ext == ".pdf":
        with pymupdf.open(path) as pdf:
            return "\n".join(page.get_text("text") for page in pdf).strip()
    if ext == ".docx":
        doc = WordDocument(path)
        chunks = [p.text for p in doc.paragraphs if p.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                chunks.append(" | ".join(cell.text.strip() for cell in row.cells))
        return "\n".join(chunks).strip()
    return path.read_text(encoding="utf-8-sig", errors="replace").strip()

def parse_date(raw: str) -> datetime | None:
    raw = raw.strip().rstrip(".,;: ")
    raw = re.sub(r"(?i)(\d)(st|nd|rd|th)\b", r"\1", raw)
    raw = re.sub(r"\s+", " ", raw)
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(raw, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None

def categorize(text: str, filename: str = "") -> str:
    haystack = f"{filename} {text[:20000]}".lower()
    scores = {category: sum(haystack.count(term) for term in terms) for category, terms in CATEGORY_RULES.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "Other"

def summarize(text: str, max_sentences: int = 3) -> str:
    sentences = [re.sub(r"\s+", " ", s).strip() for s in re.split(r"(?<=[.!?])\s+|\n+", text) if len(s.strip()) > 25]
    if not sentences:
        return ""
    if len(sentences) <= max_sentences:
        return " ".join(sentences)[:1200]
    counts: dict[str, int] = {}
    for word in re.findall(r"[a-zA-Z]{3,}", text.lower()):
        counts[word] = counts.get(word, 0) + 1
    ranked = []
    for index, sentence in enumerate(sentences):
        words = re.findall(r"[a-zA-Z]{3,}", sentence.lower())
        score = sum(counts.get(w, 0) for w in words) / max(len(words), 1)
        if any(k in sentence.lower() for k in KEYWORDS):
            score *= 1.5
        ranked.append((score, index, sentence))
    selected = sorted(ranked, reverse=True)[:max_sentences]
    return " ".join(s for _, _, s in sorted(selected, key=lambda item: item[1]))[:1200]

def analyze_text(text: str, filename: str = "") -> dict[str, Any]:
    fields: dict[str, str] = {}
    email = re.search(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", text, re.I)
    phone = re.search(r"(?<!\w)(?:\+?\d{1,3}[\s.-]?)?(?:\(?\d{3,5}\)?[\s.-]?)\d{5,8}(?!\w)", text)
    if email:
        fields["Email"] = email.group(0)
    if phone:
        fields["Phone"] = phone.group(0).strip()
    for label, value in LABEL_DATE_RE.findall(text):
        date_match = DATE_RE.search(value)
        if not date_match:
            continue
        parsed = parse_date(date_match.group(0))
        if parsed:
            key = re.sub(r"\s+", " ", label.strip()).title()
            fields[key] = parsed.strftime("%b %d, %Y").replace(" 0", " ")
    # Extract explicitly labelled business entities only; avoid guessing unlabelled names.
    entity_re = re.compile(r"(?im)^\s*(supplier|vendor|buyer|customer|licence holder|license holder|issued to|company name|business name|contracting party|party)\s*[:\-]\s*(.{2,100})$")
    for label, value in entity_re.findall(text):
        fields[label.strip().title()] = value.strip()[:500]
    # Preserve explicit key:value fields as facts. These are source labels, not inferred values.
    labelled_line_re = re.compile(r"(?im)^\s*([A-Za-z][A-Za-z0-9 _/#().-]{1,45})\s*:\s*(.{1,300})$")
    for label, value in labelled_line_re.findall(text):
        key = re.sub(r"\s+", " ", label.strip()).title()
        clean_value = value.strip()
        if clean_value and key not in fields:
            fields[key] = clean_value[:500]
    # Capture additional explicitly labelled business dates, separate from auto-deadline rules.
    other_date_re = re.compile(r"(?im)^\s*(invoice date|date of invoice|issue date|issued on|start date|effective date|contract date|filing date|execution date)\s*[:\-]?\s*(.{0,70})$")
    for label, value in other_date_re.findall(text):
        date_match = DATE_RE.search(value)
        if date_match and (parsed := parse_date(date_match.group(0))):
            fields[label.strip().title()] = parsed.strftime("%b %d, %Y").replace(" 0", " ")
    category = categorize(text, filename)
    keywords = [word for word in KEYWORDS if re.search(r"\b" + re.escape(word) + r"\b", text, re.I)]
    headings = []
    for line in text.splitlines():
        clean = line.strip()
        if 3 <= len(clean) <= 100 and (clean.isupper() or re.match(r"^(section\s+)?\d+(?:\.\d+)*[.)]?\s+[A-Z]", clean, re.I)):
            headings.append(clean)
    deadlines = []
    for label, value in LABEL_DATE_RE.findall(text):
        match = DATE_RE.search(value)
        if match and (parsed := parse_date(match.group(0))):
            label_l = label.lower()
            kind = "expiry" if any(w in label_l for w in ("expiry", "expiration", "expires", "valid until", "renew")) else "due"
            deadlines.append({"title": f"{label.strip().title()} — {Path(filename).name}", "description": f"Detected from explicitly labelled text: {label.strip()}", "due_date": parsed.isoformat(), "kind": kind})
    notices = []
    if not text:
        notices.append("No selectable text was extracted. Scanned-image OCR is not included.")
    if not fields:
        notices.append("No supported labelled fields were found by the configured patterns.")
    return {"category": category, "summary": summarize(text), "fields": fields, "important_keywords": keywords, "important_sections": headings[:20], "detected_deadlines": deadlines, "notices": notices}

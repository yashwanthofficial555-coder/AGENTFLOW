"""Twice-weekly pending-action reminders and completion notices."""
import logging
from datetime import datetime, timedelta, timezone
from sqlalchemy import select
from app.database import SessionLocal
from app.models import AppNotification, Deadline, Document
from app.services.documents import refresh_deadline_status
from app.services.gmail import send_gmail_email

logger = logging.getLogger(__name__)


def add_in_app_notification(db, kind: str, title: str, message: str) -> AppNotification:
    item = AppNotification(kind=kind, title=title, message=message)
    db.add(item)
    return item


def _pending_digest(db) -> tuple[list[Deadline], list[Document]]:
    now = datetime.now(timezone.utc)
    horizon = now + timedelta(days=14)
    deadlines = db.scalars(select(Deadline).order_by(Deadline.due_date.asc())).all()
    pending = []
    for item in deadlines:
        refresh_deadline_status(item)
        due = item.due_date
        if due.tzinfo is None:
            due = due.replace(tzinfo=timezone.utc)
        if item.status != "Completed" and (item.status == "Overdue" or due <= horizon):
            pending.append(item)
    review_docs = db.scalars(select(Document).where(Document.status == "Needs review").order_by(Document.uploaded_at.desc())).all()
    return pending, review_docs


def run_twice_weekly_reminder() -> dict:
    """Persist an in-app digest and email it if a Gmail account is connected."""
    with SessionLocal() as db:
        deadlines, review_docs = _pending_digest(db)
        lines = []
        overdue = [d for d in deadlines if d.status == "Overdue"]
        upcoming = [d for d in deadlines if d.status == "Upcoming"]
        if overdue:
            lines.append(f"OVERDUE ({len(overdue)}):")
            lines.extend(f"• {d.title} — due {d.due_date.date().isoformat()}" for d in overdue)
        if upcoming:
            lines.append(f"UPCOMING WITHIN 14 DAYS ({len(upcoming)}):")
            lines.extend(f"• {d.title} — due {d.due_date.date().isoformat()}" for d in upcoming)
        if review_docs:
            lines.append(f"DOCUMENTS NEEDING REVIEW ({len(review_docs)}):")
            lines.extend(f"• {d.filename}" for d in review_docs)
        if not lines:
            return {"deadlines": 0, "review_documents": 0, "email_sent": False, "skipped": "No unfinished items"}
        message = "Your twice-weekly DocuMind reminder. Completed actions are excluded.\n\n" + "\n".join(lines)
        add_in_app_notification(db, "weekly_reminder", "Twice-weekly unfinished-items reminder", message)
        db.commit()
        try:
            sent = send_gmail_email("DocuMind: unfinished deadlines and reviews", message)
        except Exception:
            logger.exception("Gmail reminder delivery failed; the in-app reminder was still saved")
            sent = False
        return {"deadlines": len(deadlines), "review_documents": len(review_docs), "email_sent": sent}


def send_completion_notice(title: str, document_name: str | None = None) -> None:
    details = f"\nRelated document: {document_name}" if document_name else ""
    try:
        send_gmail_email("DocuMind: action completed", f"Completed action: {title}{details}\n\nThis completed item will not appear in unfinished-item reminders.")
    except Exception:
        logger.exception("Completion email failed; the in-app completed record remains available")


def scheduled_weekly_reminder() -> None:
    try:
        run_twice_weekly_reminder()
    except Exception:
        logger.exception("Twice-weekly reminder job failed")

"""Google OAuth and Gmail API delivery. OAuth tokens are Fernet-encrypted at rest."""
import base64
import hashlib
import json
import logging
import secrets
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from urllib.parse import urlencode

import httpx
from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.config import (
    GMAIL_TOKEN_ENCRYPTION_KEY,
    GOOGLE_CLIENT_ID,
    GOOGLE_CLIENT_SECRET,
    GOOGLE_REDIRECT_URI,
)
from app.database import SessionLocal
from app.models import GmailConnection, GmailOAuthState

logger = logging.getLogger(__name__)
AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
USERINFO_URL = "https://openidconnect.googleapis.com/v1/userinfo"
SEND_URL = "https://gmail.googleapis.com/gmail/v1/users/me/messages/send"
SCOPES = "openid email https://www.googleapis.com/auth/gmail.send"


class GmailConfigurationError(RuntimeError):
    pass


class GmailDeliveryError(RuntimeError):
    pass


def _fernet() -> Fernet:
    if not GMAIL_TOKEN_ENCRYPTION_KEY:
        raise GmailConfigurationError("Set GMAIL_TOKEN_ENCRYPTION_KEY before connecting Gmail.")
    try:
        return Fernet(GMAIL_TOKEN_ENCRYPTION_KEY.encode("ascii"))
    except (ValueError, TypeError, UnicodeEncodeError) as exc:
        raise GmailConfigurationError("GMAIL_TOKEN_ENCRYPTION_KEY must be a valid Fernet key.") from exc


def config_status() -> dict:
    missing=[]
    if not GOOGLE_CLIENT_ID: missing.append("GOOGLE_CLIENT_ID")
    if not GOOGLE_CLIENT_SECRET: missing.append("GOOGLE_CLIENT_SECRET")
    if not GOOGLE_REDIRECT_URI: missing.append("GOOGLE_REDIRECT_URI")
    if not GMAIL_TOKEN_ENCRYPTION_KEY: missing.append("GMAIL_TOKEN_ENCRYPTION_KEY")
    if missing:
        return {"configured": False, "message": "Add " + ", ".join(missing) + " to backend/.env."}
    try:
        _fernet()
    except GmailConfigurationError as exc:
        return {"configured": False, "message": str(exc)}
    return {"configured": True, "message": "Google OAuth is ready."}


def oauth_authorization_url(db: Session) -> str:
    status = config_status()
    if not status["configured"]:
        raise GmailConfigurationError(status["message"])
    state = secrets.token_urlsafe(32)
    verifier = secrets.token_urlsafe(48)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
    db.execute(delete(GmailOAuthState).where(GmailOAuthState.expires_at < datetime.now(timezone.utc)))
    db.add(GmailOAuthState(
        state_hash=hashlib.sha256(state.encode()).hexdigest(),
        code_verifier=verifier,
        expires_at=datetime.now(timezone.utc) + timedelta(minutes=10),
    ))
    db.commit()
    params = {
        "client_id": GOOGLE_CLIENT_ID,
        "redirect_uri": GOOGLE_REDIRECT_URI,
        "response_type": "code",
        "scope": SCOPES,
        "access_type": "offline",
        "prompt": "consent",
        "include_granted_scopes": "true",
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    return f"{AUTH_URL}?{urlencode(params)}"


def consume_oauth_state(db: Session, state: str) -> str | None:
    state_hash = hashlib.sha256(state.encode()).hexdigest()
    row = db.get(GmailOAuthState, state_hash)
    if not row:
        return None
    verifier = row.code_verifier
    expires_at = row.expires_at
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    db.delete(row)
    db.commit()
    return verifier if expires_at > datetime.now(timezone.utc) else None


def _decode_tokens(connection: GmailConnection) -> dict:
    try:
        return json.loads(_fernet().decrypt(connection.encrypted_tokens.encode()).decode())
    except (InvalidToken, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise GmailConfigurationError("Stored Gmail authorization cannot be decrypted. Reconnect Gmail and check the token encryption key.") from exc


def _save_tokens(db: Session, email: str, tokens: dict, existing: GmailConnection | None = None) -> GmailConnection:
    if existing is not None:
        previous = _decode_tokens(existing)
        if not tokens.get("refresh_token"):
            tokens["refresh_token"] = previous.get("refresh_token")
        existing.email = email
        existing.encrypted_tokens = _fernet().encrypt(json.dumps(tokens).encode()).decode()
        existing.updated_at = datetime.now(timezone.utc)
        db.add(existing)
        db.commit()
        db.refresh(existing)
        return existing
    connection = GmailConnection(
        id=1,
        email=email,
        encrypted_tokens=_fernet().encrypt(json.dumps(tokens).encode()).decode(),
    )
    db.add(connection)
    db.commit()
    db.refresh(connection)
    return connection


def exchange_authorization_code(db: Session, code: str, verifier: str) -> str:
    try:
        response = httpx.post(TOKEN_URL, data={
            "code": code,
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "redirect_uri": GOOGLE_REDIRECT_URI,
            "grant_type": "authorization_code",
            "code_verifier": verifier,
        }, timeout=20)
        response.raise_for_status()
        tokens = response.json()
        profile = httpx.get(USERINFO_URL, headers={"Authorization": f"Bearer {tokens['access_token']}"}, timeout=15)
        profile.raise_for_status()
        email = profile.json().get("email", "").strip().lower()
        if not email:
            raise GmailDeliveryError("Google did not return an email address for this account.")
        tokens["expires_at"] = datetime.now(timezone.utc).timestamp() + int(tokens.get("expires_in", 3600))
        existing = db.get(GmailConnection, 1)
        _save_tokens(db, email, tokens, existing)
        return email
    except GmailDeliveryError:
        raise
    except (httpx.HTTPError, KeyError, ValueError) as exc:
        logger.warning("Google OAuth exchange failed: %s", type(exc).__name__)
        raise GmailDeliveryError("Google authorization failed. Check OAuth settings, redirect URI, Gmail API access, and consent-screen configuration.") from exc


def _fresh_access_token(db: Session, connection: GmailConnection) -> str:
    tokens = _decode_tokens(connection)
    expires_at = float(tokens.get("expires_at", 0))
    if expires_at > datetime.now(timezone.utc).timestamp() + 90:
        return tokens["access_token"]
    refresh = tokens.get("refresh_token")
    if not refresh:
        raise GmailDeliveryError("Gmail authorization expired. Reconnect Gmail in Settings.")
    try:
        response = httpx.post(TOKEN_URL, data={
            "client_id": GOOGLE_CLIENT_ID,
            "client_secret": GOOGLE_CLIENT_SECRET,
            "refresh_token": refresh,
            "grant_type": "refresh_token",
        }, timeout=20)
        response.raise_for_status()
        updated = response.json()
        tokens["access_token"] = updated["access_token"]
        tokens["expires_at"] = datetime.now(timezone.utc).timestamp() + int(updated.get("expires_in", 3600))
        _save_tokens(db, connection.email, tokens, connection)
        return tokens["access_token"]
    except (httpx.HTTPError, KeyError, ValueError) as exc:
        logger.warning("Google token refresh failed: %s", type(exc).__name__)
        raise GmailDeliveryError("Could not refresh Gmail authorization. Reconnect Gmail in Settings.") from exc


def send_gmail_email(subject: str, body: str) -> bool:
    """Send to the connected Google account. Returns False when Gmail is not configured/connected."""
    if not config_status()["configured"]:
        return False
    with SessionLocal() as db:
        connection = db.get(GmailConnection, 1)
        if not connection:
            return False
        access_token = _fresh_access_token(db, connection)
        message = EmailMessage()
        message["To"] = connection.email
        message["From"] = connection.email
        message["Subject"] = subject
        message.set_content(body)
        raw = base64.urlsafe_b64encode(message.as_bytes()).decode().rstrip("=")
        try:
            response = httpx.post(SEND_URL, headers={"Authorization": f"Bearer {access_token}"}, json={"raw": raw}, timeout=25)
            response.raise_for_status()
            return True
        except httpx.HTTPError as exc:
            logger.warning("Gmail send failed: %s", type(exc).__name__)
            raise GmailDeliveryError("Gmail could not send the notification. Reconnect Gmail or check the account's Gmail API access.") from exc


def disconnect_gmail(db: Session) -> None:
    connection = db.get(GmailConnection, 1)
    if connection:
        try:
            tokens = _decode_tokens(connection)
            revoke = tokens.get("refresh_token") or tokens.get("access_token")
            if revoke:
                httpx.post("https://oauth2.googleapis.com/revoke", data={"token": revoke}, timeout=10)
        except Exception:
            logger.warning("Could not revoke Google authorization remotely; deleting local tokens anyway")
        db.delete(connection)
    db.execute(delete(GmailOAuthState))
    db.commit()


def connected_email(db: Session) -> str | None:
    connection = db.get(GmailConnection, 1)
    return connection.email if connection else None

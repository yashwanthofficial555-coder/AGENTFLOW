from datetime import datetime, timedelta, timezone
from pathlib import Path
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.models import ActivityEvent, Category, Deadline, Document, ExtractedField
from app.services.analysis import analyze_text, extract_text
from app.utils.formatting import format_size, display_datetime

CATEGORY_DESCRIPTIONS = {"Invoice":"Billing and payment documents", "Contract":"Agreements, leases and contracts", "Licence":"Business licences and permits", "Certificate":"Certificates and attestations", "Purchase Order":"Purchase orders", "Tax Document":"Tax filings and returns", "Other":"Uncategorized documents"}

def ensure_category(db: Session, name: str) -> Category:
    category = db.scalar(select(Category).where(Category.name == name))
    if not category:
        category = Category(name=name, description=CATEGORY_DESCRIPTIONS.get(name, ""))
        db.add(category)
        db.flush()
    return category

def document_dict(doc: Document) -> dict:
    return {"id":doc.id,"filename":doc.filename,"name":doc.filename,"category":doc.category_name,"date":display_datetime(doc.uploaded_at),"uploaded_at":doc.uploaded_at,"size":format_size(doc.size_bytes),"size_bytes":doc.size_bytes,"extension":doc.extension,"mime_type":doc.mime_type,"status":doc.status,"compliance":doc.compliance_status,"summary":doc.summary,"fields":{f.key:f.value for f in doc.fields},"text_available":bool(doc.extracted_text)}

def deadline_dict(item: Deadline) -> dict:
    return {"id":item.id,"title":item.title,"description":item.description,"due_date":item.due_date,"date":display_datetime(item.due_date),"priority":item.priority,"status":item.status,"source":item.source,"document_id":item.document_id,"document_name":item.document.filename if item.document else None}

def add_activity(db: Session, event_type: str, message: str, document_id: int | None = None) -> None:
    db.add(ActivityEvent(event_type=event_type, message=message, document_id=document_id))

def _refresh_analysis(db: Session, doc: Document, storage_path: Path) -> dict:
    text = extract_text(storage_path, doc.extension)
    result = analyze_text(text, doc.filename)
    doc.extracted_text = text
    doc.summary = result["summary"]
    doc.category_name = result["category"]
    category = ensure_category(db, doc.category_name)
    doc.category_rel = category
    doc.status = "Processed" if text else "Needs review"
    expiry_dates = [datetime.fromisoformat(x["due_date"]).date() for x in result["detected_deadlines"] if x["kind"] == "expiry"]
    today = datetime.now(timezone.utc).date()
    doc.compliance_status = "Attention required" if any(day < today for day in expiry_dates) else "Upcoming" if any(day <= today + timedelta(days=30) for day in expiry_dates) else "Attention required" if not text else "—"
    # Flush orphan deletions before inserting the newly extracted field set; the table
    # enforces one row per (document, field key).
    for old_field in list(doc.fields):
        db.delete(old_field)
    db.flush()
    doc.fields.clear()
    for key, value in result["fields"].items():
        doc.fields.append(ExtractedField(key=key, value=value, confidence="rule"))
    for old in list(doc.deadlines):
        if old.source == "automatic":
            db.delete(old)
    today = datetime.now(timezone.utc).date()
    for detected in result["detected_deadlines"]:
        due = datetime.fromisoformat(detected["due_date"])
        exists = any(d.title == detected["title"] and d.due_date.date() == due.date() for d in doc.deadlines)
        if not exists:
            delta = (due.date() - today).days
            db.add(Deadline(document=doc, title=detected["title"], description=detected["description"], due_date=due, priority="High" if delta < 8 else "Medium", status="Overdue" if delta < 0 else "Upcoming", source="automatic"))
    return result

def refresh_deadline_status(item: Deadline) -> str:
    if item.status == "Completed":
        return item.status
    due = item.due_date.date()
    if item.due_date.tzinfo is None:
        today = datetime.now().date()
    else:
        today = datetime.now(timezone.utc).date()
    item.status = "Overdue" if due < today else "Upcoming"
    return item.status

def analyze_document(db: Session, doc: Document, path: Path) -> dict:
    result = _refresh_analysis(db, doc, path)
    add_activity(db, "document.analyzed", f"Analysis completed for {doc.filename}", doc.id)
    db.commit()
    db.refresh(doc)
    return result

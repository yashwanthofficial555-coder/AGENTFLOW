from pathlib import Path
import os
from dotenv import load_dotenv

APP_DIR = Path(__file__).resolve().parent
BACKEND_DIR = APP_DIR.parent
PROJECT_DIR = BACKEND_DIR.parent
load_dotenv(BACKEND_DIR / ".env")

def _db_url() -> str:
    raw = os.getenv("DOCUMIND_DATABASE_URL")
    if raw:
        return raw
    path = Path(os.getenv("DOCUMIND_DB_PATH", str(BACKEND_DIR / "documind.db"))).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    return f"sqlite:///{path.as_posix()}"

DATABASE_URL = _db_url()
STORAGE_DIR = Path(os.getenv("DOCUMIND_STORAGE_DIR", str(BACKEND_DIR / "storage" / "documents"))).expanduser().resolve()
STORAGE_DIR.mkdir(parents=True, exist_ok=True)
MAX_FILE_SIZE = int(os.getenv("DOCUMIND_MAX_FILE_SIZE", str(15 * 1024 * 1024)))
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt", ".md"}
CORS_ORIGINS = [x.strip() for x in os.getenv("DOCUMIND_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if x.strip()]
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.1-flash-lite").strip()
GOOGLE_CLIENT_ID = os.getenv("GOOGLE_CLIENT_ID", "").strip()
GOOGLE_CLIENT_SECRET = os.getenv("GOOGLE_CLIENT_SECRET", "").strip()
GOOGLE_REDIRECT_URI = os.getenv("GOOGLE_REDIRECT_URI", "http://localhost:8000/api/gmail/callback").strip()
GMAIL_FRONTEND_URL = os.getenv("GMAIL_FRONTEND_URL", "http://localhost:5173").strip().rstrip("/")
GMAIL_TOKEN_ENCRYPTION_KEY = os.getenv("GMAIL_TOKEN_ENCRYPTION_KEY", "").strip()
GMAIL_CONFIGURED = bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET and GOOGLE_REDIRECT_URI and GMAIL_TOKEN_ENCRYPTION_KEY)

import logging
from contextlib import asynccontextmanager
from zoneinfo import ZoneInfo
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import select
from alembic import command
from alembic.config import Config
from app.config import BACKEND_DIR, CORS_ORIGINS, GEMINI_API_KEY, GEMINI_MODEL
from app.database import SessionLocal
from app.models import Category
from app.routes import assistant, categories, dashboard, deadlines, documents, search, gmail, notifications
from app.services.documents import CATEGORY_DESCRIPTIONS
from app.services.notifications import scheduled_weekly_reminder

logging.basicConfig(level=logging.INFO,format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger=logging.getLogger("documind")

def initialize() -> None:
    migration_config=Config(str(BACKEND_DIR/"alembic.ini"))
    migration_config.set_main_option("script_location",str(BACKEND_DIR/"migrations"))
    command.upgrade(migration_config,"head")
    with SessionLocal() as db:
        for name,description in CATEGORY_DESCRIPTIONS.items():
            if not db.scalar(select(Category).where(Category.name==name)):
                db.add(Category(name=name,description=description))
        db.commit()

@asynccontextmanager
async def lifespan(app:FastAPI):
    scheduler=None
    if app.state.initialize_database:
        initialize()
        scheduler=AsyncIOScheduler(timezone=ZoneInfo("Asia/Kolkata"))
        scheduler.add_job(scheduled_weekly_reminder,"cron",day_of_week="mon,thu",hour=9,minute=0,id="twice-weekly-documind-reminder",coalesce=True,max_instances=1,misfire_grace_time=3600)
        scheduler.start()
        app.state.notification_scheduler=scheduler
    try:
        yield
    finally:
        if scheduler and scheduler.running:
            scheduler.shutdown(wait=False)

def create_app(initialize_database:bool=True)->FastAPI:
    app=FastAPI(title="DocuMind Rule-Based Document API",version="1.0.0",description="Local document management with deterministic rule-based processing. Gemini is optional for chat only; document extraction stays local.",lifespan=lifespan)
    app.state.initialize_database=initialize_database
    app.add_middleware(CORSMiddleware,allow_origins=CORS_ORIGINS,allow_credentials=False,allow_methods=["GET","POST","PATCH","DELETE","OPTIONS"],allow_headers=["Content-Type","Accept"])
    app.include_router(documents.router);app.include_router(deadlines.router);app.include_router(search.router);app.include_router(dashboard.router);app.include_router(categories.router);app.include_router(assistant.router);app.include_router(gmail.router);app.include_router(notifications.router)
    @app.get("/api/health",tags=["health"])
    def health():return {"status":"ok","service":"documind-backend","processing":"deterministic-rules","assistant_mode":"gemini" if GEMINI_API_KEY else "rule-based","gemini_configured":bool(GEMINI_API_KEY),"model":GEMINI_MODEL if GEMINI_API_KEY else None}
    @app.get("/",include_in_schema=False)
    def root():return {"service":"DocuMind API","docs":"/docs","health":"/api/health"}
    return app

app=create_app()

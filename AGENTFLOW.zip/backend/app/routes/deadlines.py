from datetime import datetime, timezone
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Response
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload
from app.database import get_db
from app.models import Deadline, Document
from app.schemas.documents import DeadlineCreate, DeadlineOut, DeadlineUpdate
from app.services.documents import add_activity, deadline_dict, refresh_deadline_status
from app.services.notifications import add_in_app_notification, send_completion_notice

router=APIRouter(prefix="/api/deadlines",tags=["deadlines"])
PRIORITIES={"low","medium","high"}; STATUSES={"upcoming","overdue","completed"}

def _deadline(db:Session,item_id:int)->Deadline:
    item=db.scalar(select(Deadline).options(selectinload(Deadline.document)).where(Deadline.id==item_id))
    if not item:raise HTTPException(404,"Deadline not found")
    return item

@router.get("",response_model=list[DeadlineOut])
def list_deadlines(status_filter:str|None=Query(None,alias="status"),priority:str|None=None,from_date:datetime|None=None,to_date:datetime|None=None,document_id:int|None=None,db:Session=Depends(get_db)):
    stmt=select(Deadline).options(selectinload(Deadline.document)).order_by(Deadline.due_date.asc())
    if status_filter:stmt=stmt.where(Deadline.status.ilike(status_filter))
    if priority:stmt=stmt.where(Deadline.priority.ilike(priority))
    if from_date:stmt=stmt.where(Deadline.due_date>=from_date)
    if to_date:stmt=stmt.where(Deadline.due_date<=to_date)
    if document_id:stmt=stmt.where(Deadline.document_id==document_id)
    rows=db.scalars(stmt).all();changed=False
    for row in rows:
        old=row.status;refresh_deadline_status(row);changed|=old!=row.status
    if changed:db.commit()
    return [DeadlineOut(**deadline_dict(row)) for row in rows]

@router.post("",response_model=DeadlineOut,status_code=201)
def create_deadline(payload:DeadlineCreate,db:Session=Depends(get_db)):
    if payload.priority.lower() not in PRIORITIES:raise HTTPException(422,"Priority must be Low, Medium or High")
    if payload.document_id is not None and not db.get(Document,payload.document_id):raise HTTPException(404,"Linked document not found")
    due=payload.due_date if payload.due_date.tzinfo else payload.due_date.replace(tzinfo=timezone.utc)
    item=Deadline(title=payload.title.strip(),description=payload.description,due_date=due,priority=payload.priority.title(),document_id=payload.document_id,source="manual")
    refresh_deadline_status(item);db.add(item);db.flush();add_activity(db,"deadline.created",f"Created deadline: {item.title}",item.document_id);db.commit();return DeadlineOut(**deadline_dict(_deadline(db,item.id)))

@router.patch("/{deadline_id}",response_model=DeadlineOut)
def update_deadline(deadline_id:int,payload:DeadlineUpdate,db:Session=Depends(get_db)):
    item=_deadline(db,deadline_id);updates=payload.model_dump(exclude_unset=True)
    if "priority" in updates and updates["priority"] and updates["priority"].lower() not in PRIORITIES:raise HTTPException(422,"Priority must be Low, Medium or High")
    if "status" in updates and updates["status"] and updates["status"].lower() not in STATUSES:raise HTTPException(422,"Status must be Upcoming, Overdue or Completed")
    if "document_id" in updates and updates["document_id"] is not None and not db.get(Document,updates["document_id"]):raise HTTPException(404,"Linked document not found")
    for key,value in updates.items():
        if key=="due_date" and value and value.tzinfo is None:value=value.replace(tzinfo=timezone.utc)
        if key in {"priority","status"} and value:value=value.title()
        setattr(item,key,value)
    if item.status!="Completed":refresh_deadline_status(item)
    add_activity(db,"deadline.updated",f"Updated deadline: {item.title}",item.document_id);db.commit();return DeadlineOut(**deadline_dict(_deadline(db,deadline_id)))

@router.post("/{deadline_id}/complete",response_model=DeadlineOut)
def complete_deadline(deadline_id:int,background_tasks:BackgroundTasks,db:Session=Depends(get_db)):
    item=_deadline(db,deadline_id);item.status="Completed"
    document_name=item.document.filename if item.document else None
    add_activity(db,"deadline.completed",f"Completed deadline: {item.title}",item.document_id)
    add_in_app_notification(db,"completed",f"Completed: {item.title}",f"This action is now in the Completed section and will be excluded from unfinished-item reminders.")
    db.commit()
    background_tasks.add_task(send_completion_notice,item.title,document_name)
    return DeadlineOut(**deadline_dict(_deadline(db,deadline_id)))

@router.delete("/{deadline_id}",status_code=204)
def delete_deadline(deadline_id:int,db:Session=Depends(get_db)):
    item=_deadline(db,deadline_id);name=item.title;document_id=item.document_id;db.delete(item);add_activity(db,"deadline.deleted",f"Deleted deadline: {name}",document_id);db.commit();return Response(status_code=204)

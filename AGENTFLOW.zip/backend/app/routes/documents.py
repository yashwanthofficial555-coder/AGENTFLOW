import logging
import mimetypes
import re
import uuid
from pathlib import Path
from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy import or_, select, func
from sqlalchemy.orm import Session, selectinload
from app.config import ALLOWED_EXTENSIONS, MAX_FILE_SIZE, STORAGE_DIR
from app.database import get_db
from app.models import ActivityEvent, Document, ExtractedField
from app.schemas.documents import AnalysisOut, DocumentOut, DocumentPage, FieldPatch
from app.services.documents import add_activity, analyze_document, document_dict
from app.services.notifications import add_in_app_notification

logger=logging.getLogger(__name__)
router=APIRouter(prefix="/api/documents",tags=["documents"])

def _load(db:Session, document_id:int)->Document:
    doc=db.scalar(select(Document).options(selectinload(Document.fields),selectinload(Document.deadlines)).where(Document.id==document_id))
    if not doc: raise HTTPException(status_code=404,detail="Document not found")
    return doc

def _safe_path(storage_name:str)->Path:
    path=(STORAGE_DIR/storage_name).resolve()
    if not path.is_relative_to(STORAGE_DIR): raise HTTPException(status_code=400,detail="Invalid document identifier")
    return path

@router.post("/upload",response_model=DocumentOut,status_code=status.HTTP_201_CREATED)
async def upload_document(file:UploadFile=File(...),db:Session=Depends(get_db)):
    original=(file.filename or "").replace("\\","/").split("/")[-1].strip()
    original=re.sub(r"[\x00-\x1f\x7f]", "", original)[:255]
    if not original: raise HTTPException(400,"A valid filename is required")
    ext=Path(original).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS: raise HTTPException(415, f"Unsupported file type. Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}")
    payload=await file.read(MAX_FILE_SIZE+1)
    if not payload: raise HTTPException(400,"Uploaded file is empty")
    if len(payload)>MAX_FILE_SIZE: raise HTTPException(413,f"File exceeds the {MAX_FILE_SIZE // (1024*1024)} MB limit")
    if ext==".pdf" and not payload.startswith(b"%PDF-"): raise HTTPException(422,"File content is not a valid PDF")
    if ext==".docx" and not payload.startswith(b"PK"): raise HTTPException(422,"File content is not a valid DOCX archive")
    if ext in {".txt",".md"} and b"\x00" in payload: raise HTTPException(422,"Text file contains binary data")
    storage_name=f"{uuid.uuid4().hex}{ext}"
    path=_safe_path(storage_name)
    tmp=path.with_suffix(path.suffix+".part")
    try:
        tmp.write_bytes(payload); tmp.replace(path)
        doc=Document(filename=original,storage_name=storage_name,extension=ext,mime_type=mimetypes.guess_type(original)[0] or file.content_type or "application/octet-stream",size_bytes=len(payload),status="Processing")
        db.add(doc);db.flush()
        analyze_document(db,doc,path)
        if doc.status=="Needs review":
            add_in_app_notification(db,"needs_review",f"Review required: {doc.filename}","The uploaded document has no selectable text. Check the original file; scanned-image OCR is not included.")
            db.commit()
        return DocumentOut(**document_dict(doc))
    except HTTPException:
        db.rollback();path.unlink(missing_ok=True);tmp.unlink(missing_ok=True);raise
    except Exception as exc:
        db.rollback();path.unlink(missing_ok=True);tmp.unlink(missing_ok=True)
        logger.exception("Document upload or extraction failed for %s",original)
        raise HTTPException(422,"The document could not be read. Check that it is a valid, unencrypted PDF or DOCX.") from exc
    finally:
        await file.close()

@router.get("",response_model=DocumentPage)
def list_documents(q:str|None=None,category:str|None=None,status_filter:str|None=Query(None,alias="status"),date_from:str|None=None,date_to:str|None=None,sort_by:str="uploaded_at",order:str="desc",page:int=Query(1,ge=1),page_size:int=Query(50,ge=1,le=200),db:Session=Depends(get_db)):
    stmt=select(Document).options(selectinload(Document.fields))
    if q:
        like=f"%{q.strip()}%"
        stmt=stmt.where(or_(Document.filename.ilike(like),Document.extracted_text.ilike(like),Document.summary.ilike(like),Document.category_name.ilike(like)))
    if category and category.lower() not in {"all","all documents"}: stmt=stmt.where(func.lower(Document.category_name)==category.lower().rstrip("s")) if category.lower().endswith("s") else stmt.where(func.lower(Document.category_name)==category.lower())
    if status_filter: stmt=stmt.where(func.lower(Document.status)==status_filter.lower())
    if date_from: stmt=stmt.where(func.date(Document.uploaded_at)>=date_from)
    if date_to: stmt=stmt.where(func.date(Document.uploaded_at)<=date_to)
    total=db.scalar(select(func.count()).select_from(stmt.order_by(None).subquery())) or 0
    sort_col={"uploaded_at":Document.uploaded_at,"filename":Document.filename,"size":Document.size_bytes,"category":Document.category_name}.get(sort_by,Document.uploaded_at)
    stmt=stmt.order_by(sort_col.asc() if order.lower()=="asc" else sort_col.desc()).offset((page-1)*page_size).limit(page_size)
    return {"items":[DocumentOut(**document_dict(d)) for d in db.scalars(stmt).all()],"total":total,"page":page,"page_size":page_size}

@router.get("/{document_id}",response_model=DocumentOut)
def get_document(document_id:int,db:Session=Depends(get_db)):
    return DocumentOut(**document_dict(_load(db,document_id)))

@router.get("/{document_id}/text")
def get_document_text(document_id:int,db:Session=Depends(get_db)):
    doc=_load(db,document_id)
    return {"document_id":doc.id,"text":doc.extracted_text,"available":bool(doc.extracted_text)}

@router.get("/{document_id}/download")
def download_document(document_id:int,db:Session=Depends(get_db)):
    doc=_load(db,document_id);path=_safe_path(doc.storage_name)
    if not path.is_file(): raise HTTPException(404,"Stored document file is missing")
    return FileResponse(path,media_type=doc.mime_type,filename=doc.filename)

@router.delete("/{document_id}",status_code=204)
def delete_document(document_id:int,db:Session=Depends(get_db)):
    doc=_load(db,document_id);path=_safe_path(doc.storage_name);name=doc.filename
    db.delete(doc);db.add(ActivityEvent(event_type="document.deleted",message=f"Deleted {name}"));db.commit();path.unlink(missing_ok=True)

@router.post("/{document_id}/analyze",response_model=AnalysisOut)
def reanalyze_document(document_id:int,db:Session=Depends(get_db)):
    doc=_load(db,document_id);path=_safe_path(doc.storage_name)
    if not path.is_file(): raise HTTPException(404,"Stored document file is missing")
    try: result=analyze_document(db,doc,path)
    except Exception as exc:
        logger.exception("Analysis failed for document %s",document_id)
        raise HTTPException(422,"Document analysis failed") from exc
    return AnalysisOut(document_id=doc.id,**result)

@router.patch("/{document_id}/fields",response_model=DocumentOut)
def update_fields(document_id:int,payload:FieldPatch,db:Session=Depends(get_db)):
    doc=_load(db,document_id)
    fields={f.key:f for f in doc.fields}
    for key,value in payload.fields.items():
        key=key.strip()
        if not key or len(key)>100: raise HTTPException(422,"Field names must be 1–100 characters")
        if key in fields: fields[key].value=value
        else: doc.fields.append(ExtractedField(key=key,value=value,confidence="user"))
    doc.status="Processed";add_activity(db,"document.fields_updated",f"Fields updated for {doc.filename}",doc.id);db.commit();db.refresh(doc)
    return DocumentOut(**document_dict(_load(db,document_id)))

from datetime import datetime, timezone
from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import AppNotification

router = APIRouter(prefix="/api/notifications", tags=["notifications"])


def notification_dict(item: AppNotification) -> dict:
    return {"id": item.id, "kind": item.kind, "title": item.title, "message": item.message, "created_at": item.created_at, "read": item.read_at is not None}


@router.get("")
def list_notifications(db: Session = Depends(get_db)):
    items = db.scalars(select(AppNotification).order_by(AppNotification.created_at.desc(), AppNotification.id.desc()).limit(50)).all()
    unread_count=db.scalar(select(func.count()).select_from(AppNotification).where(AppNotification.read_at.is_(None))) or 0
    return {"items": [notification_dict(item) for item in items], "unread_count": unread_count}


@router.post("/read-all")
def mark_all_read(db: Session = Depends(get_db)):
    now = datetime.now(timezone.utc)
    for item in db.scalars(select(AppNotification).where(AppNotification.read_at.is_(None))).all():
        item.read_at = now
    db.commit()
    return {"ok": True}

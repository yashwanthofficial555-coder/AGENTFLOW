import logging
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
import httpx

from app.config import GMAIL_FRONTEND_URL
from app.database import get_db
from app.services.gmail import (
    GmailConfigurationError,
    GmailDeliveryError,
    config_status,
    connected_email,
    consume_oauth_state,
    disconnect_gmail,
    exchange_authorization_code,
    oauth_authorization_url,
    send_gmail_email,
)

router = APIRouter(prefix="/api/gmail", tags=["gmail notifications"])
logger = logging.getLogger(__name__)


@router.get("/status")
def gmail_status(db: Session = Depends(get_db)):
    config = config_status()
    email = connected_email(db)
    return {
        **config,
        "connected": bool(email),
        "email": email,
        "schedule": {"days": ["Monday", "Thursday"], "time": "09:00", "timezone": "Asia/Kolkata"},
        "scope": "Send notification email only; DocuMind does not read Gmail inbox messages.",
    }


@router.get("/connect")
def connect_gmail(db: Session = Depends(get_db)):
    try:
        return RedirectResponse(oauth_authorization_url(db), status_code=302)
    except GmailConfigurationError as exc:
        raise HTTPException(503, detail=str(exc)) from exc


@router.get("/callback")
def gmail_callback(code: str | None = None, state: str | None = None, error: str | None = None, db: Session = Depends(get_db)):
    if error:
        return RedirectResponse(f"{GMAIL_FRONTEND_URL}/?gmail=cancelled", status_code=303)
    if not code or not state:
        return RedirectResponse(f"{GMAIL_FRONTEND_URL}/?gmail=error", status_code=303)
    verifier = consume_oauth_state(db, state)
    if not verifier:
        return RedirectResponse(f"{GMAIL_FRONTEND_URL}/?gmail=expired", status_code=303)
    try:
        exchange_authorization_code(db, code, verifier)
        return RedirectResponse(f"{GMAIL_FRONTEND_URL}/?gmail=connected", status_code=303)
    except (GmailConfigurationError, GmailDeliveryError):
        logger.exception("Gmail authorization callback failed")
        return RedirectResponse(f"{GMAIL_FRONTEND_URL}/?gmail=error", status_code=303)


@router.post("/disconnect")
def disconnect(db: Session = Depends(get_db)):
    disconnect_gmail(db)
    return {"connected": False, "message": "Gmail disconnected and locally stored authorization removed."}


@router.post("/test")
def send_test_email(db: Session = Depends(get_db)):
    email = connected_email(db)
    if not email:
        raise HTTPException(409, "Connect a Gmail account before sending a test notification.")
    try:
        sent = send_gmail_email("DocuMind Gmail connection test", "Gmail is connected to DocuMind. Scheduled reminders are set for Monday and Thursday at 9:00 AM Asia/Kolkata. Only notification messages are sent; your inbox is not read.")
    except GmailDeliveryError as exc:
        raise HTTPException(502, detail=str(exc)) from exc
    return {"sent": sent, "recipient": email}

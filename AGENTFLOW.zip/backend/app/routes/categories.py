from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Category

router=APIRouter(prefix="/api/categories",tags=["categories"])
@router.get("")
def list_categories(db:Session=Depends(get_db)):
    return [{"id":c.id,"name":c.name,"description":c.description,"document_count":len(c.documents)} for c in db.scalars(select(Category).order_by(Category.name)).all()]

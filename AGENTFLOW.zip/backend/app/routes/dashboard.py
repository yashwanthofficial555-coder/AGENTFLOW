from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import ActivityEvent, Deadline, Document
from app.schemas.dashboard import DashboardOut
from app.services.documents import deadline_dict, document_dict, refresh_deadline_status

router=APIRouter(prefix="/api",tags=["dashboard"])
@router.get("/dashboard",response_model=DashboardOut)
def dashboard(db:Session=Depends(get_db)):
    now=datetime.now(timezone.utc);today=now.date();month_ago=now-timedelta(days=29)
    documents=db.scalars(select(Document).order_by(Document.uploaded_at.desc())).all()
    deadlines=db.scalars(select(Deadline).order_by(Deadline.due_date.asc())).all()
    changed=False
    for d in deadlines:
        before=d.status;refresh_deadline_status(d);changed|=before!=d.status
    if changed:db.commit()
    cats={}
    for d in documents:cats[d.category_name]=cats.get(d.category_name,0)+1
    upcoming=[d for d in deadlines if d.status=="Upcoming" and d.due_date.date()<=today+timedelta(days=30)]
    overdue=[d for d in deadlines if d.status=="Overdue"]
    recent=[document_dict(d) for d in documents[:8]]
    event_rows=db.scalars(select(ActivityEvent).order_by(ActivityEvent.created_at.desc()).limit(20)).all()
    counts={}
    for d in documents:
        stamp=d.uploaded_at
        if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=timezone.utc)
        if stamp>=month_ago:
            key=stamp.date().isoformat();counts[key]=counts.get(key,0)+1
    uploads=[]
    for offset in range(29,-1,-1):
        day=(today-timedelta(days=offset)).isoformat();uploads.append({"date":day,"count":counts.get(day,0)})
    return {"total_documents":len(documents),"processed_documents":sum(d.status=="Processed" for d in documents),"needs_review":sum(d.status=="Needs review" for d in documents),"total_storage_bytes":sum(d.size_bytes for d in documents),"upcoming_deadlines":len(upcoming),"overdue_deadlines":len(overdue),"completed_deadlines":sum(d.status=="Completed" for d in deadlines),"documents_by_category":cats,"recent_documents":recent,"deadlines":[deadline_dict(d) for d in (overdue+upcoming)[:10]],"activity":event_rows,"uploads_by_day":uploads}

@router.get("/dashboard/stats")
def dashboard_stats(db:Session=Depends(get_db)):
    result=dashboard(db)
    return result

@router.get("/dashboard/activity")
def dashboard_activity(limit:int=20,db:Session=Depends(get_db)):
    return [{"id":e.id,"event_type":e.event_type,"message":e.message,"document_id":e.document_id,"created_at":e.created_at} for e in db.scalars(select(ActivityEvent).order_by(ActivityEvent.created_at.desc()).limit(max(1,min(limit,100)))).all()]

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, selectinload
from app.database import get_db
from app.models import Document
from app.schemas.documents import DocumentOut, SearchOut
from app.services.documents import document_dict

router=APIRouter(prefix="/api",tags=["search"])

@router.get("/search",response_model=SearchOut)
def search_documents(q:str=Query("",max_length=300),category:str|None=None,date_from:str|None=None,date_to:str|None=None,sort_by:str="uploaded_at",order:str="desc",limit:int=Query(50,ge=1,le=200),db:Session=Depends(get_db)):
    stmt=select(Document).options(selectinload(Document.fields))
    if q.strip():
        like=f"%{q.strip()}%";stmt=stmt.where(or_(Document.filename.ilike(like),Document.extracted_text.ilike(like),Document.summary.ilike(like),Document.category_name.ilike(like)))
    if category:stmt=stmt.where(func.lower(Document.category_name)==category.lower().rstrip("s"))
    if date_from:stmt=stmt.where(func.date(Document.uploaded_at)>=date_from)
    if date_to:stmt=stmt.where(func.date(Document.uploaded_at)<=date_to)
    col={"filename":Document.filename,"category":Document.category_name,"size":Document.size_bytes}.get(sort_by,Document.uploaded_at)
    stmt=stmt.order_by(col.asc() if order.lower()=="asc" else col.desc()).limit(limit)
    rows=db.scalars(stmt).all()
    return SearchOut(query=q,total=len(rows),items=[DocumentOut(**document_dict(d)) for d in rows])

@router.get("/search/status")
def search_status():return {"available":True,"mode":"sqlite-like-match","fields":["filename","category","summary","extracted_text"]}

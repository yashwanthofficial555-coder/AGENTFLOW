from datetime import date, datetime
from pydantic import BaseModel, ConfigDict, Field

class FieldOut(BaseModel):
    key: str
    value: str
    confidence: str = "rule"
    model_config = ConfigDict(from_attributes=True)

class DocumentOut(BaseModel):
    id: int
    filename: str
    category: str
    date: str
    uploaded_at: datetime
    size: str
    size_bytes: int
    extension: str
    mime_type: str
    status: str
    compliance: str
    summary: str
    fields: dict[str, str]
    text_available: bool
    model_config = ConfigDict(from_attributes=True)

class DocumentPage(BaseModel):
    items: list[DocumentOut]
    total: int
    page: int
    page_size: int

class FieldPatch(BaseModel):
    fields: dict[str, str] = Field(default_factory=dict)

class AnalysisOut(BaseModel):
    document_id: int
    category: str
    summary: str
    fields: dict[str, str]
    important_keywords: list[str]
    important_sections: list[str]
    detected_deadlines: list[dict]
    notices: list[str]

class SearchOut(BaseModel):
    query: str
    total: int
    items: list[DocumentOut]

class DeadlineCreate(BaseModel):
    title: str = Field(min_length=1, max_length=220)
    description: str = ""
    due_date: datetime
    priority: str = "Medium"
    document_id: int | None = None

class DeadlineUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=220)
    description: str | None = None
    due_date: datetime | None = None
    priority: str | None = None
    status: str | None = None
    document_id: int | None = None

class DeadlineOut(BaseModel):
    id: int
    title: str
    description: str
    due_date: datetime
    date: str
    priority: str
    status: str
    source: str
    document_id: int | None
    document_name: str | None = None
    model_config = ConfigDict(from_attributes=True)

from datetime import datetime
from pydantic import BaseModel, ConfigDict

class ActivityOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    event_type: str
    message: str
    document_id: int | None
    created_at: datetime

class DashboardOut(BaseModel):
    total_documents: int
    processed_documents: int
    needs_review: int
    total_storage_bytes: int
    upcoming_deadlines: int
    overdue_deadlines: int
    completed_deadlines: int
    documents_by_category: dict[str, int]
    recent_documents: list[dict]
    deadlines: list[dict]
    activity: list[ActivityOut]
    uploads_by_day: list[dict]

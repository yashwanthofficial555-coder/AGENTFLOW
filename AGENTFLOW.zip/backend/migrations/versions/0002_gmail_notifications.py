"""Add encrypted Gmail connection and in-app notification tables."""
from alembic import op
import sqlalchemy as sa

revision = "0002_gmail_notifications"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "gmail_connections",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("email", sa.String(length=320), nullable=False),
        sa.Column("encrypted_tokens", sa.Text(), nullable=False),
        sa.Column("connected_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_gmail_connections_email", "gmail_connections", ["email"])
    op.create_table(
        "gmail_oauth_states",
        sa.Column("state_hash", sa.String(length=64), primary_key=True),
        sa.Column("code_verifier", sa.String(length=128), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_gmail_oauth_states_expires_at", "gmail_oauth_states", ["expires_at"])
    op.create_table(
        "app_notifications",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("kind", sa.String(length=40), nullable=False),
        sa.Column("title", sa.String(length=220), nullable=False),
        sa.Column("message", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("read_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_app_notifications_kind", "app_notifications", ["kind"])
    op.create_index("ix_app_notifications_created_at", "app_notifications", ["created_at"])


def downgrade():
    op.drop_index("ix_app_notifications_created_at", table_name="app_notifications")
    op.drop_index("ix_app_notifications_kind", table_name="app_notifications")
    op.drop_table("app_notifications")
    op.drop_index("ix_gmail_oauth_states_expires_at", table_name="gmail_oauth_states")
    op.drop_table("gmail_oauth_states")
    op.drop_index("ix_gmail_connections_email", table_name="gmail_connections")
    op.drop_table("gmail_connections")

# Gmail notifications (Google OAuth)

DocuMind does **not** collect Gmail passwords. The user selects **Connect Gmail**, signs in on Google’s own page, reviews a send-only consent screen, and returns to DocuMind. Inbox-reading access is not requested.

## Google Cloud setup

1. Create/select a Google Cloud project and enable the **Gmail API**.
2. Configure the OAuth consent screen. For testing, add the account that will connect as a test user.
3. Create an OAuth client with application type **Web application**.
4. Register the callback URL exactly as `GOOGLE_REDIRECT_URI` below. For local development, use `http://localhost:8000/api/gmail/callback`. For a hosted app, register its public HTTPS callback URL instead.
5. Put the OAuth client ID and secret in the backend environment only. Do not put them in frontend variables, source, or ZIP files. For a hosted/preview app, both the registered callback URI and `GMAIL_FRONTEND_URL` must use that deployment’s exact public HTTPS URLs; temporary preview hosts are not suitable as permanent OAuth redirect URIs.

## Backend environment

Copy `backend/.env.example` to `backend/.env`, then set:

```dotenv
GOOGLE_CLIENT_ID=your-web-client-id
GOOGLE_CLIENT_SECRET=your-web-client-secret
GOOGLE_REDIRECT_URI=http://localhost:8000/api/gmail/callback
GMAIL_FRONTEND_URL=http://localhost:5173
GMAIL_TOKEN_ENCRYPTION_KEY=generated-fernet-key
```

Generate a Fernet key with:

```sh
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Keep `.env` and the Fernet key private and persistent. If the encryption key is changed after connecting, DocuMind cannot decrypt the saved authorization and the account must reconnect. Restart FastAPI after changing environment values.

## Notification behavior

- This single-workspace app stores one connected Gmail identity; every user of this local instance shares it. Per-user connections require adding application login and tenant isolation.
- The connected Gmail address receives notifications.
- Twice-weekly reminders run **Monday and Thursday at 9:00 AM Asia/Kolkata** while the backend is running. They include overdue deadlines, upcoming deadlines due within 14 days, and documents marked **Needs review**. No reminder is created or emailed when there are no unfinished items.
- Completed actions are excluded from unfinished-item reminders. Completing a deadline creates an in-app notification and queues a one-off completion email; completed deadlines remain available in the app’s **Completed** filter.
- Test the connection from Settings → Notifications → **Send test email**.
- The in-process scheduler is intended for this single-workspace, single-backend-instance app. Do not start multiple Uvicorn workers unless the scheduler is moved to a shared job queue.

If OAuth is not configured, the in-app notification center still works; Gmail connection controls report that setup is required. A test-mode OAuth consent screen may require the user’s Gmail address to be listed as a test user.

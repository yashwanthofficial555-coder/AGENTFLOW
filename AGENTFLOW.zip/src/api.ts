export type ApiDocument={id:number;filename:string;name?:string;category:string;date:string;uploaded_at:string;size:string;size_bytes:number;extension:string;mime_type:string;status:string;compliance:string;summary:string;fields:Record<string,string>;text_available:boolean};
export type ApiDeadline={id:number;title:string;description:string;due_date:string;date:string;priority:string;status:string;source:string;document_id:number|null;document_name:string|null};
export type GmailStatus={configured:boolean;connected:boolean;email:string|null;message:string;schedule:{days:string[];time:string;timezone:string};scope:string};
export type AppNotification={id:number;kind:string;title:string;message:string;created_at:string;read:boolean};
export type DashboardData={total_documents:number;processed_documents:number;needs_review:number;total_storage_bytes:number;upcoming_deadlines:number;overdue_deadlines:number;completed_deadlines:number;documents_by_category:Record<string,number>;recent_documents:ApiDocument[];deadlines:ApiDeadline[];activity:{id:number;event_type:string;message:string;document_id:number|null;created_at:string}[];uploads_by_day:{date:string;count:number}[]};
const root=(import.meta.env.VITE_API_BASE_URL||'').replace(/\/$/,'');
async function request<T>(path:string,init:RequestInit={}):Promise<T>{const headers=new Headers(init.headers);if(init.body&&!(init.body instanceof FormData)&&!headers.has('Content-Type'))headers.set('Content-Type','application/json');const response=await fetch(`${root}${path}`,{...init,headers});if(!response.ok){let message=`Request failed (${response.status})`;try{const data=await response.json();message=typeof data.detail==='string'?data.detail:message}catch{}throw new Error(message)}if(response.status===204)return undefined as T;return response.json() as Promise<T>}
export const api={
 health:()=>request<{status:string;service:string;processing:string;assistant_mode:string;gemini_configured:boolean;model:string|null}>('/api/health'),
 documents:async()=>{const x=await request<{items:ApiDocument[];total:number}>('/api/documents?page=1&page_size=200');return x.items},
 document:(id:number)=>request<ApiDocument>(`/api/documents/${id}`),
 upload:(file:File)=>{const body=new FormData();body.append('file',file);return request<ApiDocument>('/api/documents/upload',{method:'POST',body})},
 deleteDocument:(id:number)=>request<void>(`/api/documents/${id}`,{method:'DELETE'}),
 reanalyze:(id:number)=>request(`/api/documents/${id}/analyze`,{method:'POST'}),
 updateFields:(id:number,fields:Record<string,string>)=>request<ApiDocument>(`/api/documents/${id}/fields`,{method:'PATCH',body:JSON.stringify({fields})}),
 text:(id:number)=>request<{document_id:number;text:string;available:boolean}>(`/api/documents/${id}/text`),
 deadlines:()=>request<ApiDeadline[]>('/api/deadlines'),
 createDeadline:(data:{title:string;description:string;due_date:string;priority:string;document_id?:number})=>request<ApiDeadline>('/api/deadlines',{method:'POST',body:JSON.stringify(data)}),
 completeDeadline:(id:number)=>request<ApiDeadline>(`/api/deadlines/${id}/complete`,{method:'POST'}),
 updateDeadline:(id:number,data:Partial<ApiDeadline>)=>request<ApiDeadline>(`/api/deadlines/${id}`,{method:'PATCH',body:JSON.stringify(data)}),
 deleteDeadline:(id:number)=>request<void>(`/api/deadlines/${id}`,{method:'DELETE'}),
 dashboard:()=>request<DashboardData>('/api/dashboard'),
 search:(q:string)=>request<{items:ApiDocument[];total:number}>(`/api/search?q=${encodeURIComponent(q)}`),
 assistantStatus:()=>request<{available:boolean;mode:string;gemini_configured:boolean;model:string|null}>('/api/assistant/status'),
 gmailStatus:()=>request<GmailStatus>('/api/gmail/status'),
 gmailConnectUrl:()=>`${root}/api/gmail/connect`,
 gmailDisconnect:()=>request<{connected:boolean;message:string}>('/api/gmail/disconnect',{method:'POST'}),
 gmailTest:()=>request<{sent:boolean;recipient:string}>('/api/gmail/test',{method:'POST'}),
 notifications:()=>request<{items:AppNotification[];unread_count:number}>('/api/notifications'),
 markNotificationsRead:()=>request<{ok:boolean}>('/api/notifications/read-all',{method:'POST'}),
 ask:(question:string)=>request<{answer:string;sources:{type:string;id:number;title?:string;filename?:string;document?:string}[];mode:string;disclaimer:string}>('/api/assistant/ask',{method:'POST',body:JSON.stringify({question})}),
 downloadUrl:(id:number)=>`${root}/api/documents/${id}/download`
};
export function mapDocument(d:ApiDocument){return {id:d.id,name:d.filename,category:d.category,date:d.date,size:d.size,status:d.status,compliance:d.compliance,fields:d.fields,summary:d.summary};}
export function mapDeadline(d:ApiDeadline){return {id:d.id,title:d.title,doc:d.document_name||'No linked document',date:d.date,due_date:d.due_date,priority:d.priority,status:d.status,description:d.description};}

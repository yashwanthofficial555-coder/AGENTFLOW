# DocuMind — local rule-based document intelligence

This repository now contains a connected React frontend and a local FastAPI backend. Document extraction, categorization, labelled-field/date detection, document search, summaries, and deadlines use conventional Python rules and SQLite. The assistant is rule-based by default and can optionally use Gemini when a server-side `GEMINI_API_KEY` is configured.

## Start the backend

Windows CMD:

```cmd
cd backend
py -3.11 -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
alembic upgrade head
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

macOS/Linux:

```bash
cd backend
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
alembic upgrade head
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Swagger: <http://127.0.0.1:8000/docs>. Detailed endpoint and behavior notes: [`backend/README.md`](backend/README.md).

### Optional Gemini assistant

Document processing remains local and rule-based. To enable Gemini only for chat, first rotate the API key that was pasted into the conversation, then put the new key in the ignored `backend/.env` as `GEMINI_API_KEY=...` and restart FastAPI. The key is not in source or ZIP files. When enabled, relevant question context and selected extracted document text are sent to Google; do not enable it for sensitive records unless approved. Without a key, the rule-based assistant is used.

## Start the frontend

In a second terminal at the repository root:

```bash
npm install
cp .env.example .env
npm run dev
```

The Vite dev server proxies `/api` to `http://127.0.0.1:8000`. Set `VITE_API_BASE_URL` in the frontend `.env` only when the browser must contact a separately hosted backend directly. Build production assets using `npm run build`.

## Verify

```bash
cd backend
set PYTHONPATH=.
pytest -q
```

From the root, `npm run build` type-checks and builds the frontend. The current automated backend suite exercises upload/extraction, PDF and DOCX, rule-based analysis, search, deadlines, download/delete, dashboard, fields and assistant APIs.

## Important operating limits

- This is a single-user, single-local-database system with no app-account authentication, authorization, or workspace separation. Optional Gmail notifications use Google OAuth (send-only scope): unfinished reminders run Monday/Thursday at 9 AM Asia/Kolkata, and completed actions get a separate in-app/email notification. See `backend/GMAIL_SETUP.md`; Google OAuth credentials are required to enable email delivery.
- Scanned PDFs do not receive OCR. PyMuPDF extracts selectable text only.
- Rule-based extraction only reports values it explicitly matches. Validate extracted data and dates manually.
- The backend makes no claim of legal compliance; an empty compliance finding is shown as `—`.
- Keep the service bound to localhost unless you add authentication and deployment hardening. Do not expose personal business documents to an untrusted network.
- The included frontend has no demo-data fallback: when the API is offline, it displays the backend connection state and an empty/retryable live data view.
